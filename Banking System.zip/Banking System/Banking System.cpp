

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account
{
private:
    string accountNumber; //identifier for account
    double balance; // account balance

public:
    // initializes account with a balance
    Account(string accNum, double bal) : accountNumber(accNum), balance(bal) {}

    //Operator overloading
    Account& operator+(double amount); // deposit
    Account& operator-(double amount); // withdraw
    friend ostream& operator<<(ostream& os, const Account& acc); // display

    //Placeholder for transaction history
    void addTransaction(double amount, string type);
};

class User
{
private:
    string username; //stores username
    string password; // stores users password
    vector<Account> accounts; //user can have multiple accounts

public:
    // initializes user with username and password
    User(string user, string pass) : username(user), password(pass) {}

    // placeholder for authentification
    bool authenticate(string inputPass);
};

class Transaction 
{
public:
    double amount; // amount for transaction
    string type; // type of transaction
    //initializes transaction with amount and type
    Transaction(double amt, string t) : amount(amt), type(t) {}
};

int main()
{
    cout << "Banking System Initialized" << endl;
    return 0;
}


